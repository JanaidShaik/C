﻿using Microsoft.Extensions.Logging;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.ComponentModel;

namespace EventEase.Models
{
    public class Event
    {
        public int EventID { get; set; }
        
        public string EventName { get; set; }
        public string EventDescription { get; set; }
        public DateTime EventDate { get; set; }

        public List<Booking> Bookings { get; set; } = new();


        

      
    }
}
