﻿using EventEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Controllers
{
    public class EventController : Controller
    {
        // GET Event
        private readonly ApplicationDbContext _context;

        public EventController(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index(string searchString)
        {
            if (_context.Event == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Venue'  is null.");
            }
            var events = from e in _context.Event
                         select e;

            if (!String.IsNullOrEmpty(searchString))
            {
                events = events.Where(e => e.EventName!.ToUpper().Contains(searchString.ToUpper()));
            }
            return View(await events.ToListAsync());

        }



        // GET code for create
        public IActionResult Create()
        {
            return View();
        }


        //POST code for create
        [HttpPost]
        public async Task<IActionResult> Create(Event events)
        {
            if (ModelState.IsValid)
            {
                _context.Add(events);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(events);
        }


        // GET code for delete
        public async Task<IActionResult> Delete(int id)
        {
            var events = await _context.Event.FindAsync(id);
            if (events == null)
            {
                return NotFound();
            }
            return View(events);
        }

        //POST code for delete
        [HttpPost]
        public async Task<IActionResult> Delete(Event events)     
        {
            bool hasBooking = await _context.Booking.AnyAsync(b => b.EventID == events.EventID);
            if (hasBooking)
            {
                var Events = await _context.Event.FindAsync(events.EventID);
                ModelState.AddModelError(""
                    , "Cannot delete this event. This existing booking for this event");
                return View(Events); //Returns the view with the error message displayed
            }

            var bookingtodelete = await _context.Event.FindAsync(events.EventID);

            _context.Event.Remove(bookingtodelete);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        //GET code for details
        public async Task<IActionResult> Details(int id)
        {
            var events = await _context.Event.FindAsync(id);
            if (events == null)
            {
                return NotFound();
            }
            return View(events);
        }

        private bool EventExists(int eventID)
        {
            throw new NotImplementedException();
        }

        // GET code for edit
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var events = await _context.Event.FindAsync(id);
            if (events == null)
            {
                return NotFound();
            }
            return View(events);
        }



        // POST code for edit
        [HttpPost]
        public async Task<IActionResult> Edit(int id, Event events)
        {
            if (id != events.EventID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(events);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EventExists(events.EventID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(events);
        }

       
    }












        }
