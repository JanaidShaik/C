﻿using EventEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EventEase.Controllers
{
    public class VenueController : Controller
    {
        // GET Venue
        private readonly ApplicationDbContext _context;

        public VenueController(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index(string searchString)
        {
            if(_context.Venue == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Venue'  is null.");
            }
            var venues = from v in _context.Venue
                         select v;

            if (!String.IsNullOrEmpty(searchString))
            {
                venues = venues.Where(v => v.VenueName!.ToUpper().Contains(searchString.ToUpper()));
            }
            return View(await venues.ToListAsync());

        }



        //  GET code for Create
        public IActionResult Create()
        {
            return View();
        }


        // POST code for Create
        [HttpPost]
        public async Task<IActionResult> Create(Venue venue)
        {
            if (ModelState.IsValid)
            {
                _context.Add(venue);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(venue);
        }


        //GET code for details
        public async Task<IActionResult> Details(int id)
        {
            var venue = await _context.Venue.FindAsync(id);
            if (venue == null)
            {
                return NotFound();
            }
            return View(venue);
        }

        

        //GET code for delete
        public async Task<IActionResult> Delete(int id)
        {
            var venue = await _context.Venue.FindAsync(id);
            if (venue == null)
            {
                return NotFound();
            }
            return View(venue);
        }

        //POST code  for delete
        [HttpPost]
        public async Task<IActionResult> Delete(Venue venue)
        {

            //Check if any of the venues are in booking
            bool hasBooking = await _context.Booking.AnyAsync(b => b.VenueID == venue.VenueID);
            if (hasBooking)
            {
                var venues = await _context.Venue.FindAsync(venue.VenueID);
                ModelState.AddModelError("",
                    "Cannot delete this venue. There is an existing booking for this venue");
                return View(venues); // Return the view with the error message
            }

            var bookingtodelete = await _context.Venue.FindAsync(venue.VenueID);
            _context.Venue.Remove(bookingtodelete);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

       private bool VenueExists(int id)
        {
            return _context.Venue.Any(e => e.VenueID == id);
        }

        //GET code for edit
        public async Task<IActionResult> Edit(int id)
        {
            var venue = await _context.Venue.FindAsync(id);
            if (venue == null)
            {
                return NotFound();
            }
            return View(venue);
        }

        //POST code for edit
        [HttpPost]
        public async Task<IActionResult> Edit(int id,Venue venue)
        {
            if (id != venue.VenueID)
            {
                return NotFound();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(venue);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!VenueExists(venue.VenueID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(venue);

        }








    }
}
