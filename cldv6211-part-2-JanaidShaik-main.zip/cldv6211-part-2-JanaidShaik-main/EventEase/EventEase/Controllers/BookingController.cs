﻿using EventEase.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace EventEase.Controllers
{
    public class BookingController : Controller
    {
        private readonly ApplicationDbContext _context;

        public BookingController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string SearchString)
        {
            if (_context.Booking == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Booking'  is null.");
            }
            var bookings = from b in _context.Booking
                           select b;
            if (!String.IsNullOrEmpty(SearchString))
            {
                bookings = bookings.Where(b => b.Venue!.VenueName!.ToUpper().Contains(SearchString.ToUpper()));
            }
            return View(await bookings.Include(b => b.Event).Include(b => b.Venue).ToListAsync());


        }

        //GET code for create
        public IActionResult Create()
        {
            ViewBag.Venue = _context.Venue.ToList();
            ViewBag.Event = _context.Event.ToList();
            return View();
        }

        //POST code for create
        [HttpPost]

        public async Task<IActionResult> Create(Booking booking)
        {
            if (ModelState.IsValid)
            {
                        // Find any booking with the same venue and date but different ID
                        bool doubleBooking = await _context.Booking.AnyAsync(b =>
                            b.VenueID == booking.VenueID &&
                            b.BookingDate.Date == booking.BookingDate.Date &&
                            b.BookingID != booking.BookingID);

                        if (doubleBooking)
                        {
                            // Add model error
                            ModelState.AddModelError(string.Empty,
                                "Cannot update Booking. This venue is already booked for this selected date.");

                            
                            ViewBag.Venue = await _context.Venue.ToListAsync();
                            ViewBag.Event = await _context.Event.ToListAsync();

                            // Return the view
                            return View(booking);
                        }

                        _context.Booking.Add(booking);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewBag.Venue = _context.Venue.ToList();
            ViewBag.Event = _context.Event.ToList();
            return View(booking);
        }

        //Get code for delete
        public async Task<IActionResult> Delete(int id)
        {
            var booking = await _context.Booking
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingID == id);
            if (booking == null)
            {
                return NotFound();
            }
            return View(booking);
        }

        //Post code for delete
        [HttpPost]
        public async Task<IActionResult> Delete(Booking booking)
        {
            var bookingToDelete = await _context.Booking
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingID == booking.BookingID);
            if (bookingToDelete == null)
            {
                return NotFound();
            }
            _context.Booking.Remove(bookingToDelete);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        //Get code for details
        public async Task<IActionResult> Details(int id)
        {
            var booking = await _context.Booking
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingID == id);
            if (booking == null)
            {
                return NotFound();
            }
            return View(booking);
        }

        //GET code for edit
        public async Task<IActionResult> Edit(int id)
        {
            var booking = await _context.Booking
                .Include(b => b.Event)
                .Include(b => b.Venue)
                .FirstOrDefaultAsync(b => b.BookingID == id);
            if (booking == null)
            {
                return NotFound();
            }
            ViewBag.Venue = _context.Venue.ToList();
            ViewBag.Event = _context.Event.ToList();
            return View(booking);

        }

        //POST code for edit
        [HttpPost]
        public async Task<IActionResult> Edit(Booking booking)
        {
                if (ModelState.IsValid)
                {
                    // Find any booking with the same venue and date but different ID
                    bool doubleBooking = await _context.Booking.AnyAsync(b =>
                        b.VenueID == booking.VenueID &&
                        b.BookingDate.Date == booking.BookingDate.Date &&
                        b.BookingID != booking.BookingID);

                    if (doubleBooking)
                    {
                        // Add model error
                        ModelState.AddModelError(string.Empty,
                            "Cannot update Booking. This venue is already booked for this selected date.");

                        
                        ViewBag.Venue = await _context.Venue.ToListAsync();
                        ViewBag.Event = await _context.Event.ToListAsync();

                        // Return the view
                        return View(booking);
                    }
                _context.Booking.Update(booking);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewBag.Venue = _context.Venue.ToList();
            ViewBag.Event = _context.Event.ToList();
            return View(booking);
        }






    }
}
